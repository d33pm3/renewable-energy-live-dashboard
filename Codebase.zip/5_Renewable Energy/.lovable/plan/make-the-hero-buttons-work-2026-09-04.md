# Make the hero buttons work

## What's wrong
The two buttons in the top banner — "Fetch Latest Data" and "Explore Trends" — were never given an action. Only "View Dashboard" has one (it scrolls down). So clicks do nothing, even though they look active.

## What to change
- "Fetch Latest Data": triggers the same live fetch as the refresh button lower on the page, scrolls to the data section, and shows the same progress/result messages. While a fetch is running it shows a spinner and is disabled so it can't be double-clicked.
- "Explore Trends": scrolls smoothly to the charts area.

## Technical notes
- `src/components/landing/HeroSection.tsx`: add `onFetchLatest` and `onExploreTrends` props plus a `fetching` flag; wire them to the two buttons with disabled/spinner state.
- `src/pages/Index.tsx`: pass `() => handleRefresh(true)`, a scroll-to-charts handler using the existing `chartsRef`, and the existing `refreshing` state into `HeroSection`.
- No backend or data-logic changes.
